﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using APT.Data;
using APT.Models;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using Microsoft.EntityFrameworkCore;


namespace APT.Controllers
{
    public class UsersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UsersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ==========================
        // LOGIN
        // GET + POST: /users/login
        // ==========================
        public IActionResult Login()
        {
            // Đã login → đá về dashboard
            if (HttpContext.Session.GetInt32("user_id") != null)
                return RedirectToAction("Index", "Dashboard");

            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                ViewBag.EmailErr = "Vui lòng nhập email";
                return View();
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ViewBag.PasswordErr = "Vui lòng nhập mật khẩu";
                return View();
            }

            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            if (user == null)
            {
                ViewBag.EmailErr = "Email không tồn tại";
                return View();
            }

            bool isPasswordCorrect = false;

            // CASE 1: BCrypt
            if (BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                isPasswordCorrect = true;
            }
            // CASE 2: MD5 + Salt (legacy)
            else if (!string.IsNullOrEmpty(user.Salt))
            {
                var md5 = CreateMD5(password + user.Salt);
                if (md5 == user.Password)
                    isPasswordCorrect = true;
            }

            if (!isPasswordCorrect)
            {
                ViewBag.PasswordErr = "Mật khẩu không đúng";
                return View();
            }

            // LOGIN OK → tạo session
            CreateUserSession(user);
            return RedirectToAction("Index", "Dashboard");
        }

        // ==========================
        // CREATE SESSION
        // ==========================
        private void CreateUserSession(User user)
        {
            HttpContext.Session.SetInt32("user_id", user.Id);
            HttpContext.Session.SetString("user_email", user.Email);
            HttpContext.Session.SetString("user_name", user.FullName ?? "");
            HttpContext.Session.SetString("role", user.Role);
            HttpContext.Session.SetString("user_avatar", user.Avatar ?? "");
        }

        // ==========================
        // LOGOUT
        // ==========================
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // ==========================
        // PROFILE
        // GET + POST: /users/profile
        // ==========================
        public IActionResult Profile()
        {
            var userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
                return RedirectToAction("Login");

            var user = _context.Users.Find(userId);
            return View(user);
        }

        [HttpPost]
        public IActionResult Profile(string fullname, string phone, IFormFile avatar)
        {
            var userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
                return RedirectToAction("Login");

            var user = _context.Users.Find(userId);
            if (user == null)
                return RedirectToAction("Login");

            user.FullName = fullname;
            user.Phone = phone;

            // Upload avatar
            if (avatar != null && avatar.Length > 0)
            {
                var ext = Path.GetExtension(avatar.FileName).ToLower();
                var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif" };

                if (allowed.Contains(ext))
                {
                    var fileName = $"avatar_{userId}_{System.DateTime.Now.Ticks}{ext}";
                    var path = Path.Combine("wwwroot/images/avatars", fileName);

                    if (!Directory.Exists("wwwroot/images/avatars"))
                        Directory.CreateDirectory("wwwroot/images/avatars");

                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        avatar.CopyTo(stream);
                    }

                    user.Avatar = fileName;
                    HttpContext.Session.SetString("user_avatar", fileName);
                }
            }

            _context.SaveChanges();
            HttpContext.Session.SetString("user_name", user.FullName ?? "");

            TempData["msg_flash"] = "Cập nhật hồ sơ thành công!";
            return RedirectToAction("Profile");
        }

        // ==========================
        // CHANGE PASSWORD
        // POST: /users/change_password
        // ==========================
        [HttpPost]
        public IActionResult ChangePassword(
            string current_password,
            string new_password,
            string confirm_password)
        {
            var userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
                return RedirectToAction("Login");

            if (new_password != confirm_password)
            {
                TempData["msg_flash"] = "Mật khẩu xác nhận không khớp.";
                return RedirectToAction("Profile");
            }

            if (new_password.Length < 6)
            {
                TempData["msg_flash"] = "Mật khẩu mới phải có ít nhất 6 ký tự.";
                return RedirectToAction("Profile");
            }

            var user = _context.Users.Find(userId);
            if (user == null)
                return RedirectToAction("Login");

            bool checkOldPass = false;

            if (BCrypt.Net.BCrypt.Verify(current_password, user.Password))
                checkOldPass = true;
            else if (!string.IsNullOrEmpty(user.Salt))
            {
                if (CreateMD5(current_password + user.Salt) == user.Password)
                    checkOldPass = true;
            }

            if (!checkOldPass)
            {
                TempData["msg_flash"] = "Mật khẩu hiện tại không đúng.";
                return RedirectToAction("Profile");
            }

            // Luôn lưu mật khẩu mới = BCrypt
            user.Password = BCrypt.Net.BCrypt.HashPassword(new_password);
            user.Salt = null;

            _context.SaveChanges();
            TempData["msg_flash"] = "Đổi mật khẩu thành công!";
            return RedirectToAction("Profile");
        }

        // ==========================
        // MD5 HELPER
        // ==========================
        private string CreateMD5(string input)
        {
            using (var md5 = MD5.Create())
            {
                var bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
                var sb = new StringBuilder();
                foreach (var b in bytes)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
    }
}
